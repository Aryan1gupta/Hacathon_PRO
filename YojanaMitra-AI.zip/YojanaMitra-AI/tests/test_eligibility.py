"""Unit tests for the YojanaMitra AI scholarship eligibility engine.

Uses only the standard library unittest module.
Run with: python -m unittest tests.test_eligibility
"""

import copy
import unittest

from engine.eligibility import (
    check_scheme,
    STATUS_POTENTIAL,
    STATUS_NOT_MATCHED,
    STATUS_NEEDS_VERIFICATION,
)

SCHEME = {
    "id": "t1",
    "name_en": "Test",
    "eligibility": {
        "states": ["All India"],
        "education_levels": ["Undergraduate"],
        "max_family_income": 250000,
        "course_keywords": [],
        "other_conditions": ["Caste certificate"],
    },
}

PROFILE = {
    "state": "Bihar",
    "education": "Undergraduate",
    "course": "B.Tech",
    "year": "2nd Year",
    "income": 100000,
}


def _scheme_without_other_conditions():
    """Return a copy of SCHEME with other_conditions removed."""
    scheme = copy.deepcopy(SCHEME)
    scheme["eligibility"].pop("other_conditions", None)
    return scheme


class EligibilityTests(unittest.TestCase):
    """Tests for check_scheme covering status and reason rules."""

    def test_full_profile_with_other_conditions_needs_verification(self):
        """A matching profile still needs verification when other conditions exist."""
        result = check_scheme(SCHEME, PROFILE)
        self.assertEqual(result["status"], STATUS_NEEDS_VERIFICATION)
        self.assertFalse(any(r["result"] == "fail" for r in result["reasons"]))

    def test_all_hard_rules_met_without_other_conditions_is_potential(self):
        """A matching profile with no extra conditions is a potential match."""
        result = check_scheme(_scheme_without_other_conditions(), PROFILE)
        self.assertEqual(result["status"], STATUS_POTENTIAL)

    def test_education_class_12_is_not_matched(self):
        """An education level outside the scheme's list is not matched."""
        profile = dict(PROFILE, education="Class 12")
        result = check_scheme(SCHEME, profile)
        self.assertEqual(result["status"], STATUS_NOT_MATCHED)
        self.assertTrue(any(r["result"] == "fail" for r in result["reasons"]))

    def test_income_above_limit_is_not_matched(self):
        """Family income above the maximum limit is not matched."""
        profile = dict(PROFILE, income=300000)
        result = check_scheme(SCHEME, profile)
        self.assertEqual(result["status"], STATUS_NOT_MATCHED)

    def test_state_not_in_scheme_list_is_not_matched(self):
        """A state outside the scheme's state list is not matched."""
        scheme = copy.deepcopy(SCHEME)
        scheme["eligibility"]["states"] = ["Kerala"]
        result = check_scheme(scheme, PROFILE)
        self.assertEqual(result["status"], STATUS_NOT_MATCHED)

    def test_missing_income_never_potential(self):
        """Missing income gives needs verification, never a potential match."""
        profile = dict(PROFILE, income=None)
        result = check_scheme(_scheme_without_other_conditions(), profile)
        self.assertEqual(result["status"], STATUS_NEEDS_VERIFICATION)
        self.assertNotEqual(result["status"], STATUS_POTENTIAL)

    def test_profile_none_never_potential(self):
        """A missing profile gives needs verification, never a potential match."""
        result = check_scheme(_scheme_without_other_conditions(), None)
        self.assertEqual(result["status"], STATUS_NEEDS_VERIFICATION)
        self.assertNotEqual(result["status"], STATUS_POTENTIAL)

    def test_income_exactly_at_limit_does_not_fail(self):
        """Income equal to the limit is accepted and produces no fail reason."""
        profile = dict(PROFILE, income=250000)
        result = check_scheme(SCHEME, profile)
        self.assertFalse(any(r["result"] == "fail" for r in result["reasons"]))

    def test_course_keyword_mismatch_needs_verification(self):
        """An unrecognised course keyword is unknown, so the result needs verification."""
        scheme = copy.deepcopy(SCHEME)
        scheme["eligibility"]["course_keywords"] = ["engineering"]
        result = check_scheme(scheme, PROFILE)
        self.assertEqual(result["status"], STATUS_NEEDS_VERIFICATION)
        self.assertNotEqual(result["status"], STATUS_NOT_MATCHED)

    def test_scheme_without_eligibility_key_needs_verification(self):
        """A scheme with no eligibility rules needs verification."""
        scheme = {"id": "t10", "name_en": "No rules"}
        result = check_scheme(scheme, PROFILE)
        self.assertEqual(result["status"], STATUS_NEEDS_VERIFICATION)

    def test_hindi_reasons_contain_devanagari(self):
        """Hindi output includes at least one Devanagari character."""
        result = check_scheme(SCHEME, PROFILE, lang="hi")
        self.assertTrue(
            any(
                any("\u0900" <= ch <= "\u097f" for ch in r["text"])
                for r in result["reasons"]
            )
        )

    def test_every_reason_has_result_and_non_empty_text(self):
        """Each reason has a result key and a non-empty text string."""
        profile = dict(PROFILE, income=300000)
        result = check_scheme(SCHEME, profile)
        self.assertTrue(result["reasons"])
        for reason in result["reasons"]:
            self.assertIn("result", reason)
            self.assertIn("text", reason)
            self.assertIsInstance(reason["text"], str)
            self.assertTrue(reason["text"].strip())


if __name__ == "__main__":
    unittest.main()
