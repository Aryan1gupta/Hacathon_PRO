# -*- coding: utf-8 -*-
"""Tests for the document checklist, application tracker and deadline reminders."""

from engine.checklist import build_checklist, build_checklists
from engine.tracker import (
    init_db,
    set_status,
    get_status,
    list_statuses,
    deadline_reminders,
    STATUS_DISCOVERED,
    STATUS_DOCS_PENDING,
    STATUS_SUBMITTED,
    STATUS_USER_REPORTED,
)
from datetime import date
import os
import tempfile
import unittest


SCHEME_A = {
    "id": "a1",
    "documents": [{"en": "Aadhaar card", "hi": "आधार कार्ड"}],
    "documents_verified": False,
    "deadline": None,
    "deadline_verified": False,
}

SCHEME_B = {
    "id": "b1",
    "documents": [
        {"en": "Income certificate", "hi": "आय प्रमाण पत्र"},
        {"en": "Marksheet", "hi": "मार्कशीट"},
    ],
    "documents_verified": True,
    "deadline": "2030-06-30",
    "deadline_verified": True,
}

SCHEME_C = {
    "id": "c1",
    "documents": [],
    "deadline": "2030-06-30",
    "deadline_verified": False,
}


class ChecklistTrackerTests(unittest.TestCase):
    """Checks for checklists, status tracking and deadline reminders."""

    def setUp(self):
        # Each test gets its own temporary database file.
        self.dir = tempfile.mkdtemp()
        self.db = os.path.join(self.dir, "t.db")
        init_db(self.db)

    def tearDown(self):
        # Windows may keep the file locked, so ignore cleanup errors.
        try:
            os.remove(self.db)
            os.rmdir(self.dir)
        except OSError:
            pass

    def test_checklist_english_documents(self):
        """English checklist lists the English document names."""
        self.assertEqual(build_checklist(SCHEME_A, "en")["documents"], ["Aadhaar card"])

    def test_checklist_hindi_documents(self):
        """Hindi checklist lists the Hindi document names."""
        self.assertEqual(build_checklist(SCHEME_A, "hi")["documents"], ["आधार कार्ड"])

    def test_unverified_checklist_has_sample_note(self):
        """Unverified document lists are marked verified False and say Sample list."""
        result = build_checklist(SCHEME_A)
        self.assertIs(result["verified"], False)
        self.assertIn("Sample list", result["note"])

    def test_verified_checklist_is_true(self):
        """A scheme with verified documents gives verified True."""
        self.assertIs(build_checklist(SCHEME_B)["verified"], True)

    def test_missing_documents_key_gives_empty_list(self):
        """A scheme without a documents key gives an empty list and no crash."""
        self.assertEqual(build_checklist({"id": "x"})["documents"], [])

    def test_checklists_skip_not_matched(self):
        """Only potential matches and schemes needing verification get a checklist."""
        result = build_checklists(
            [SCHEME_A, SCHEME_B],
            {"a1": "potential_match", "b1": "not_matched"},
            "en",
        )
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["scheme_id"], "a1")

    def test_checklists_keep_schemes_order(self):
        """Both matched and needs-verification schemes are returned in input order."""
        result = build_checklists(
            [SCHEME_A, SCHEME_B],
            {"a1": "needs_verification", "b1": "potential_match"},
            "en",
        )
        self.assertEqual([item["scheme_id"] for item in result], ["a1", "b1"])

    def test_set_and_get_status_overwrites(self):
        """Setting a status twice keeps only the latest value."""
        set_status("a1", STATUS_DISCOVERED, db_path=self.db)
        self.assertEqual(get_status("a1", self.db), STATUS_DISCOVERED)
        set_status("a1", STATUS_SUBMITTED, db_path=self.db)
        self.assertEqual(get_status("a1", self.db), STATUS_SUBMITTED)
        self.assertEqual(list_statuses(self.db), {"a1": STATUS_SUBMITTED})

    def test_missing_status_is_none(self):
        """A scheme with no saved status returns None."""
        self.assertIsNone(get_status("missing", self.db))

    def test_unknown_status_raises(self):
        """An unknown status value raises ValueError."""
        with self.assertRaises(ValueError):
            set_status("a1", "bogus", db_path=self.db)

    def test_user_reported_status_with_note(self):
        """A user-reported status with a note is saved and listed."""
        set_status("a2", STATUS_USER_REPORTED, note="applied offline", db_path=self.db)
        statuses = list_statuses(self.db)
        self.assertIn("a2", statuses)
        self.assertEqual(statuses["a2"], STATUS_USER_REPORTED)

    def test_full_status_flow(self):
        """Status moves from discovered to documents pending to submitted."""
        set_status("a1", STATUS_DISCOVERED, db_path=self.db)
        self.assertEqual(get_status("a1", self.db), STATUS_DISCOVERED)
        set_status("a1", STATUS_DOCS_PENDING, db_path=self.db)
        self.assertEqual(get_status("a1", self.db), STATUS_DOCS_PENDING)
        set_status("a1", STATUS_SUBMITTED, db_path=self.db)
        self.assertEqual(get_status("a1", self.db), STATUS_SUBMITTED)

    def test_reminder_within_30_days(self):
        """Only the verified deadline within 30 days is reminded, with days left."""
        result = deadline_reminders([SCHEME_A, SCHEME_B, SCHEME_C], date(2030, 6, 1))
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["scheme_id"], "b1")
        self.assertEqual(result[0]["deadline"], "2030-06-30")
        self.assertEqual(result[0]["days_left"], 29)

    def test_no_reminder_when_more_than_30_days_away(self):
        """A verified deadline more than 30 days away gives no reminder."""
        self.assertEqual(deadline_reminders([SCHEME_B], date(2030, 1, 1)), [])

    def test_no_reminder_after_deadline(self):
        """A deadline that has already passed gives no reminder."""
        self.assertEqual(deadline_reminders([SCHEME_B], date(2030, 7, 1)), [])

    def test_unverified_deadline_never_reminded(self):
        """A deadline that is not verified never produces a reminder."""
        self.assertEqual(deadline_reminders([SCHEME_C], date(2030, 6, 20)), [])


if __name__ == "__main__":
    unittest.main()
