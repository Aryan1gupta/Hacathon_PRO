"""Tests for the Hindi and English keyword extractor in engine/nlp_extract.py."""

import unittest

from engine.nlp_extract import extract_profile_from_text, describe_found


class ExtractTests(unittest.TestCase):
    """Checks that student text is turned into education, state and income fields."""

    def test_undergraduate_state_and_income_english(self):
        """Reads undergraduate level, state and a lakh-based income in English."""
        result = extract_profile_from_text(
            "I am an undergraduate B.Tech student from Bihar, my family income is 2 lakh"
        )
        self.assertEqual(result["education"], "Undergraduate")
        self.assertEqual(result["state"], "Bihar")
        self.assertEqual(result["income"], 200000)

    def test_class_12_state_and_income_hindi(self):
        """Reads Class 12, state and a lakh-based income from Hindi text."""
        result = extract_profile_from_text(
            "मैं बिहार से हूँ, मैं बारहवीं कक्षा में पढ़ता हूँ और मेरी आय 2.5 लाख है"
        )
        self.assertEqual(result["education"], "Class 12")
        self.assertEqual(result["state"], "Bihar")
        self.assertEqual(result["income"], 250000)

    def test_matric_maps_to_class_10(self):
        """Treats 'matric' as Class 10 and leaves income empty."""
        result = extract_profile_from_text("I completed my matric in Kerala")
        self.assertEqual(result["education"], "Class 10")
        self.assertEqual(result["state"], "Kerala")
        self.assertIsNone(result["income"])

    def test_annual_income_plain_number(self):
        """Reads a plain rupee amount when an income keyword is nearby."""
        result = extract_profile_from_text("annual income 300000 rupees")
        self.assertEqual(result["income"], 300000)
        self.assertIsNone(result["education"])
        self.assertIsNone(result["state"])

    def test_income_with_indian_comma_grouping(self):
        """Reads an income written with Indian-style commas."""
        result = extract_profile_from_text("income 1,20,000")
        self.assertEqual(result["income"], 120000)

    def test_btech_means_undergraduate_without_income(self):
        """Reads B.Tech as Undergraduate and finds no income."""
        result = extract_profile_from_text("I study B.Tech")
        self.assertIsNone(result["income"])
        self.assertEqual(result["education"], "Undergraduate")

    def test_postgraduate_is_not_undergraduate(self):
        """Reads 'postgraduate' as Postgraduate, not Undergraduate."""
        result = extract_profile_from_text("I am a postgraduate student in Delhi")
        self.assertEqual(result["education"], "Postgraduate")
        self.assertEqual(result["state"], "Delhi")

    def test_empty_string_gives_nothing(self):
        """Returns all fields empty for an empty string."""
        result = extract_profile_from_text("")
        self.assertIsNone(result["state"])
        self.assertIsNone(result["education"])
        self.assertIsNone(result["income"])

    def test_none_input_gives_nothing(self):
        """Returns all fields empty when the input is None."""
        result = extract_profile_from_text(None)
        self.assertIsNone(result["state"])
        self.assertIsNone(result["education"])
        self.assertIsNone(result["income"])

    def test_two_states_are_ambiguous(self):
        """Leaves state empty when two different states are mentioned."""
        result = extract_profile_from_text("Bihar and Kerala")
        self.assertIsNone(result["state"])

    def test_two_education_levels_are_ambiguous(self):
        """Leaves education empty when two different levels are mentioned."""
        result = extract_profile_from_text("class 12 and B.Tech")
        self.assertIsNone(result["education"])

    def test_no_information_is_not_guessed(self):
        """Guesses nothing from a sentence with no profile details."""
        result = extract_profile_from_text("I want a scholarship")
        self.assertIsNone(result["state"])
        self.assertIsNone(result["education"])
        self.assertIsNone(result["income"])

    def test_hindi_state_only(self):
        """Reads a Hindi state name written in Devanagari."""
        result = extract_profile_from_text("मैं उत्तर प्रदेश का छात्र हूँ")
        self.assertEqual(result["state"], "Uttar Pradesh")

    def test_describe_found_lists_present_fields(self):
        """Lists only the fields that were actually found."""
        found = describe_found({"state": "Bihar", "education": None, "income": 200000})
        self.assertEqual(sorted(found), ["income", "state"])

    def test_bare_number_without_income_keyword_is_ignored(self):
        """Ignores a number that has no income keyword nearby."""
        result = extract_profile_from_text("I have 300000 rupees")
        self.assertIsNone(result["income"])


if __name__ == "__main__":
    unittest.main()
