"""Phase 2 tests: scholarship eligibility matching, missing-info rules and checklist links.

Uses the real data/schemes.json and the engine in engine/eligibility.py.
Standard library unittest only.
"""
import json
import os
import unittest

from engine.eligibility import (
    check_scheme,
    check_all,
    missing_fields,
    STATUS_POTENTIAL,
    STATUS_NOT_MATCHED,
    STATUS_NEEDS_VERIFICATION,
)
from engine.checklist import build_checklist

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
with open(os.path.join(BASE_DIR, "data", "schemes.json"), encoding="utf-8") as f:
    SCHEMES = json.load(f)


def by_id(sid):
    """Return the real scheme with the given id."""
    return next(s for s in SCHEMES if s["id"] == sid)


class MatchingTests(unittest.TestCase):
    """Matching rules: fit, no fit, and missing information."""

    def test_full_match_is_potential(self):
        """A student who meets every rule of sch003 (with no other conditions) is a potential match."""
        original = by_id("sch003")
        scheme = dict(original)
        scheme["eligibility"] = dict(original["eligibility"])
        scheme["eligibility"]["other_conditions"] = []
        profile = {"state": "Bihar", "education": "Undergraduate", "course": "B.A.",
                   "year": "1st Year", "income": 100000}
        result = check_scheme(scheme, profile)
        self.assertEqual(result["status"], STATUS_POTENTIAL)

    def test_income_above_limit_is_not_matched(self):
        """Income above the sch001 limit gives not matched and a failing reason."""
        profile = {"state": "Bihar", "education": "Undergraduate", "course": "B.A.",
                   "year": "1st Year", "income": 300000}
        result = check_scheme(by_id("sch001"), profile)
        self.assertEqual(result["status"], STATUS_NOT_MATCHED)
        self.assertTrue(any(r["result"] == "fail" for r in result["reasons"]))

    def test_education_not_allowed_is_not_matched(self):
        """A Class 10 student is not matched by sch003, which needs Class 12 or higher."""
        profile = {"state": "Bihar", "education": "Class 10", "course": "", "year": "",
                   "income": 100000}
        result = check_scheme(by_id("sch003"), profile)
        self.assertEqual(result["status"], STATUS_NOT_MATCHED)

    def test_missing_profile_never_matches(self):
        """With no profile at all, sch003 needs verification and is never a potential match."""
        status = check_scheme(by_id("sch003"), None)["status"]
        self.assertNotEqual(status, STATUS_POTENTIAL)
        self.assertEqual(status, STATUS_NEEDS_VERIFICATION)

    def test_missing_income_needs_verification(self):
        """A blank income on sch001 means the student needs verification and income is listed as missing."""
        profile = {"state": "Bihar", "education": "Undergraduate", "course": "",
                   "year": "1st Year", "income": None}
        result = check_scheme(by_id("sch001"), profile)
        self.assertEqual(result["status"], STATUS_NEEDS_VERIFICATION)
        self.assertEqual(missing_fields(by_id("sch001"), profile), ["income"])

    def test_income_zero_is_a_real_value(self):
        """An income of 0 is a real value, so income is not reported as missing."""
        profile = {"state": "Bihar", "education": "Undergraduate", "course": "",
                   "year": "1st Year", "income": 0}
        self.assertNotIn("income", missing_fields(by_id("sch001"), profile))

    def test_missing_education_needs_verification(self):
        """A blank education on sch003 is listed as missing and the status needs verification."""
        profile = {"state": "Bihar", "education": None, "course": "", "year": "",
                   "income": 100000}
        self.assertEqual(missing_fields(by_id("sch003"), profile), ["education"])
        result = check_scheme(by_id("sch003"), profile)
        self.assertEqual(result["status"], STATUS_NEEDS_VERIFICATION)

    def test_state_not_needed_for_all_india(self):
        """A scheme open to All India does not ask for the student's state."""
        profile = {"education": "Undergraduate", "income": 100000}
        self.assertEqual(missing_fields(by_id("sch003"), profile), [])

    def test_course_keyword_missing_needs_verification(self):
        """A missing course on sch002 is reported and never leads to a potential match."""
        profile = {"education": "Undergraduate", "course": None, "income": None,
                   "state": None, "year": None}
        self.assertIn("course", missing_fields(by_id("sch002"), profile))
        result = check_scheme(by_id("sch002"), profile)
        self.assertEqual(result["status"], STATUS_NEEDS_VERIFICATION)
        self.assertNotEqual(result["status"], STATUS_POTENTIAL)

    def test_course_keyword_present_is_not_missing(self):
        """A course that contains a keyword such as engineering is not reported as missing."""
        profile = {"education": "Undergraduate", "course": "B.Tech Engineering", "income": None,
                   "state": None, "year": None}
        self.assertNotIn("course", missing_fields(by_id("sch002"), profile))

    def test_profile_none_lists_education_and_income(self):
        """With no profile, sch001 reports education and income as missing."""
        missing = missing_fields(by_id("sch001"), None)
        self.assertIn("education", missing)
        self.assertIn("income", missing)


class ChecklistAndLinkTests(unittest.TestCase):
    """Verified-link flags, Hindi checklist and output shape."""

    def test_all_links_unverified(self):
        """Every scheme keeps link_verified set to False until it is checked by hand."""
        self.assertTrue(all(s.get("link_verified") is False for s in SCHEMES))

    def test_hindi_checklist_has_devanagari(self):
        """The Hindi checklist for sch001 has documents, and the first one contains Devanagari text."""
        checklist = build_checklist(by_id("sch001"), "hi")
        documents = checklist["documents"]
        self.assertIsInstance(documents, list)
        self.assertTrue(len(documents) > 0)
        text = documents[0]
        self.assertTrue(any('\u0900' <= ch <= '\u097f' for ch in text))

    def test_check_all_with_no_profile_returns_one_per_scheme(self):
        """check_all with no profile returns one result per scheme and none is a potential match."""
        results = check_all(SCHEMES, None)
        self.assertEqual(len(results), len(SCHEMES))
        self.assertFalse(any(r["status"] == STATUS_POTENTIAL for r in results))

    def test_hindi_reasons_contain_devanagari(self):
        """Reasons written in Hindi for sch001 contain Devanagari characters."""
        result = check_scheme(by_id("sch001"), None, lang="hi")
        self.assertTrue(len(result["reasons"]) > 0)
        for reason in result["reasons"]:
            self.assertTrue(any('\u0900' <= ch <= '\u097f' for ch in reason["text"]))


if __name__ == "__main__":
    unittest.main()
