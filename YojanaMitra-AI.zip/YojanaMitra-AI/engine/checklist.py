"""Personalised document checklist for matched schemes.

Beginner-friendly: plain functions, no external libraries.
"""


def build_checklist(scheme: dict, lang: str = "en") -> dict:
    """Return the document checklist for one scheme.

    lang is "en" or "hi". Each document in scheme["documents"] is a dict
    like {"en": "...", "hi": "..."}; we pick the right language.
    """
    documents = []
    for item in scheme.get("documents", []) or []:
        # Use Hindi text only when lang is "hi", otherwise English
        documents.append(item["hi"] if lang == "hi" else item["en"])

    # True only when the list was checked against the official source
    verified = bool(scheme.get("documents_verified", False))

    if verified:
        if lang == "hi":
            note = "दस्तावेज़ों की सूची आधिकारिक स्रोत से जाँची गई है।"
        else:
            note = "Document list checked against the official scheme source."
    else:
        if lang == "hi":
            note = "यह नमूना सूची है: आवेदन से पहले हर दस्तावेज़ आधिकारिक पोर्टल पर जाँचें।"
        else:
            note = "Sample list: confirm each document on the official portal before applying."

    return {
        "scheme_id": scheme.get("id"),
        "documents": documents,
        "verified": verified,
        "note": note,
    }


def build_checklists(schemes: list, statuses: dict, lang: str = "en") -> list:
    """Build checklists only for schemes that are potential matches or need checking.

    statuses maps scheme_id -> status string. "not_matched" schemes are skipped.
    Results keep the same order as the schemes list.
    """
    results = []
    for scheme in schemes:
        status = statuses.get(scheme.get("id"))
        # Skip schemes the student does not qualify for
        if status not in ("potential_match", "needs_verification"):
            continue
        results.append(build_checklist(scheme, lang))
    return results
