"""Application tracker (SQLite) and deadline reminders.

Beginner-friendly: uses only the standard library (sqlite3, datetime, os).
"""
import os
import sqlite3
from datetime import date, datetime

# Project folder, then the data folder where the database file lives
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "data", "tracker.db")

STATUS_DISCOVERED = "discovered"
STATUS_DOCS_PENDING = "documents_pending"
STATUS_SUBMITTED = "submitted"
STATUS_USER_REPORTED = "user_reported"
STATUSES = [STATUS_DISCOVERED, STATUS_DOCS_PENDING, STATUS_SUBMITTED, STATUS_USER_REPORTED]


def init_db(db_path: str = DB_PATH) -> None:
    """Create the data folder and the applications table if they are missing."""
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS applications ("
            "scheme_id TEXT PRIMARY KEY, "
            "status TEXT NOT NULL, "
            "note TEXT NOT NULL DEFAULT '', "
            "updated_at TEXT NOT NULL)"
        )
        conn.commit()
    finally:
        conn.close()


def set_status(scheme_id: str, status: str, note: str = "", db_path: str = DB_PATH) -> None:
    """Save or update the status of one scheme application."""
    if status not in STATUSES:
        raise ValueError("Unknown status: " + status)
    init_db(db_path)
    updated_at = datetime.now().isoformat(timespec="seconds")
    conn = sqlite3.connect(db_path)
    try:
        # Insert a new row, or update the existing row for this scheme
        conn.execute(
            "INSERT INTO applications (scheme_id, status, note, updated_at) "
            "VALUES (?, ?, ?, ?) "
            "ON CONFLICT(scheme_id) DO UPDATE SET "
            "status=excluded.status, note=COALESCE(NULLIF(excluded.note, ''), applications.note), updated_at=excluded.updated_at",
            (scheme_id, status, note, updated_at),
        )
        conn.commit()
    finally:
        conn.close()


def get_status(scheme_id: str, db_path: str = DB_PATH):
    """Return the saved status for a scheme, or None if there is no row."""
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    try:
        row = conn.execute(
            "SELECT status FROM applications WHERE scheme_id = ?", (scheme_id,)
        ).fetchone()
    finally:
        conn.close()
    return row[0] if row else None


def list_statuses(db_path: str = DB_PATH) -> dict:
    """Return a dict of scheme_id -> status for every saved application."""
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    try:
        rows = conn.execute("SELECT scheme_id, status FROM applications").fetchall()
    finally:
        conn.close()
    return {scheme_id: status for scheme_id, status in rows}


def deadline_reminders(schemes: list, today: date, within_days: int = 30) -> list:
    """Return upcoming deadlines that are verified and within the next N days.

    Unverified or missing deadlines are never included. This function does
    not touch the database.
    """
    reminders = []
    for scheme in schemes:
        # Only use deadlines that were checked against an official source
        if scheme.get("deadline_verified") is not True:
            continue
        value = scheme.get("deadline")
        if not isinstance(value, str):
            continue
        try:
            deadline_date = datetime.strptime(value, "%Y-%m-%d").date()
        except ValueError:
            continue  # not a valid YYYY-MM-DD date, so skip it
        days_left = (deadline_date - today).days
        if 0 <= days_left <= within_days:
            reminders.append({
                "scheme_id": scheme.get("id"),
                "deadline": value,
                "days_left": days_left,
            })
    reminders.sort(key=lambda item: item["days_left"])
    return reminders
