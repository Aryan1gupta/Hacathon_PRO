"""YojanaMitra AI eligibility engine.

Checks one student profile against one scheme's rules and explains
every decision with a reason. Standard library only, no Streamlit.
"""

# Result statuses (the three possible answers for a scheme)
STATUS_POTENTIAL = "potential_match"
STATUS_NOT_MATCHED = "not_matched"
STATUS_NEEDS_VERIFICATION = "needs_verification"

# Reason sentences in English ("en") and Hindi ("hi").
# {name} parts are filled in with the real values.
TEXTS = {
    "en": {
        "no_rules": "This scheme has no eligibility rules defined, so it needs verification.",
        "state_all": "This scheme is open to all of India, so your state is accepted.",
        "state_ok": "Your state {state} is allowed for this scheme.",
        "state_fail": "Your state {state} is not in the allowed states.",
        "state_missing": "State is missing in your profile, so it cannot be checked.",
        "edu_ok": "Your education {education} is allowed for this scheme.",
        "edu_fail": "Your education {education} is not in the allowed education levels.",
        "edu_missing": "Education is missing in your profile, so it cannot be checked.",
        "income_ok": "Family income Rs {income} is within the limit of Rs {limit}.",
        "income_fail": "Family income Rs {income} is above the limit of Rs {limit}.",
        "income_missing": "Family income is missing in your profile, so it cannot be checked.",
        "course_ok": "Your course {course} matches the keyword {keyword}.",
        "course_missing": "Course is missing in your profile, so it cannot be checked against the keywords ({keywords}).",
        "course_unclear": "Your course {course} does not clearly match the keywords ({keywords}), so please verify it.",
        "other": "You must verify this yourself using this document: {doc}.",
    },
    "hi": {
        "no_rules": "इस योजना के लिए कोई पात्रता नियम परिभाषित नहीं हैं, इसलिए इसकी जाँच आवश्यक है।",
        "state_all": "यह योजना पूरे भारत के लिए है, इसलिए आपका राज्य स्वीकार्य है।",
        "state_ok": "आपका राज्य {state} इस योजना के लिए स्वीकार्य है।",
        "state_fail": "आपका राज्य {state} स्वीकृत राज्यों की सूची में नहीं है।",
        "state_missing": "आपकी प्रोफ़ाइल में राज्य नहीं है, इसलिए इसकी जाँच नहीं हो सकती।",
        "edu_ok": "आपकी शिक्षा {education} इस योजना के लिए स्वीकार्य है।",
        "edu_fail": "आपकी शिक्षा {education} स्वीकृत शिक्षा स्तरों में नहीं है।",
        "edu_missing": "आपकी प्रोफ़ाइल में शिक्षा नहीं है, इसलिए इसकी जाँच नहीं हो सकती।",
        "income_ok": "पारिवारिक आय रु {income} सीमा रु {limit} के भीतर है।",
        "income_fail": "पारिवारिक आय रु {income} सीमा रु {limit} से अधिक है।",
        "income_missing": "आपकी प्रोफ़ाइल में पारिवारिक आय नहीं है, इसलिए इसकी जाँच नहीं हो सकती।",
        "course_ok": "आपका कोर्स {course} योजना के कीवर्ड {keyword} से मेल खाता है।",
        "course_missing": "आपकी प्रोफ़ाइल में कोर्स नहीं है, इसलिए कीवर्ड ({keywords}) से जाँच नहीं हो सकती।",
        "course_unclear": "आपका कोर्स {course} कीवर्ड ({keywords}) से स्पष्ट रूप से मेल नहीं खाता, कृपया सत्यापित करें।",
        "other": "आपको इस शर्त को इस दस्तावेज़ से स्वयं सत्यापित करना होगा: {doc}।",
    },
}


def pick_text(lang, key, **values):
    """Return the sentence for key in the chosen language, filled with values."""
    # Hindi only when lang is "hi"; anything else gives English.
    table = TEXTS["hi"] if lang == "hi" else TEXTS["en"]
    return table[key].format(**values)


def _clean(value):
    """Return a stripped string, or None if the value is missing or empty."""
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _income_value(value):
    """Return income as a whole number, or None if it is missing or not a number.
    Note: 0 is a valid income and is kept."""
    if value is None or value == "":
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def _in_list(value, options):
    """Case-insensitive check that value is in the list of options."""
    return value.lower() in [str(o).strip().lower() for o in options]


def _reason(result, text):
    """Build one reason entry."""
    return {"result": result, "text": text}


def check_scheme(scheme, profile, lang="en"):
    """Check one scheme against one profile and explain the result."""
    rules = scheme.get("eligibility", {}) or {}
    profile = profile or {}
    reasons = []

    # 1. State check
    allowed_states = rules.get("states") or []
    if allowed_states:
        state = _clean(profile.get("state"))
        if "All India" in allowed_states:
            reasons.append(_reason("pass", pick_text(lang, "state_all")))
        elif state is None:
            reasons.append(_reason("unknown", pick_text(lang, "state_missing")))
        elif _in_list(state, allowed_states):
            reasons.append(_reason("pass", pick_text(lang, "state_ok", state=state)))
        else:
            reasons.append(_reason("fail", pick_text(lang, "state_fail", state=state)))

    # 2. Education check
    allowed_levels = rules.get("education_levels") or []
    if allowed_levels:
        education = _clean(profile.get("education"))
        if education is None:
            reasons.append(_reason("unknown", pick_text(lang, "edu_missing")))
        elif _in_list(education, allowed_levels):
            reasons.append(_reason("pass", pick_text(lang, "edu_ok", education=education)))
        else:
            reasons.append(_reason("fail", pick_text(lang, "edu_fail", education=education)))

    # 3. Family income check (skipped when the scheme has no limit)
    limit = rules.get("max_family_income")
    if limit is not None:
        income = _income_value(profile.get("income"))
        if income is None:
            reasons.append(_reason("unknown", pick_text(lang, "income_missing")))
        elif income <= limit:
            reasons.append(_reason("pass", pick_text(lang, "income_ok", income=income, limit=limit)))
        else:
            reasons.append(_reason("fail", pick_text(lang, "income_fail", income=income, limit=limit)))

    # 4. Course keyword check (never a fail, only pass or unknown)
    keywords = [str(k).strip() for k in (rules.get("course_keywords") or []) if str(k).strip()]
    if keywords:
        course = _clean(profile.get("course"))
        keywords_text = ", ".join(keywords)
        if course is None:
            reasons.append(_reason("unknown", pick_text(lang, "course_missing", keywords=keywords_text)))
        else:
            # Find the first keyword that appears in the course (case-insensitive)
            matched = [k for k in keywords if k.lower() in course.lower()]
            if matched:
                reasons.append(_reason("pass", pick_text(lang, "course_ok", course=course, keyword=matched[0])))
            else:
                reasons.append(_reason("unknown", pick_text(lang, "course_unclear", course=course, keywords=keywords_text)))

    # 5. Other conditions: the profile cannot prove these, so each is unknown
    for doc in rules.get("other_conditions") or []:
        reasons.append(_reason("unknown", pick_text(lang, "other", doc=str(doc))))

    # A scheme with no usable rules must never be a match
    if not reasons:
        reasons.append(_reason("unknown", pick_text(lang, "no_rules")))

    # Final status: any fail -> not matched; any unknown -> needs verification
    results = [r["result"] for r in reasons]
    if "fail" in results:
        status = STATUS_NOT_MATCHED
    elif "unknown" in results:
        status = STATUS_NEEDS_VERIFICATION
    else:
        status = STATUS_POTENTIAL

    return {"scheme_id": scheme["id"], "status": status, "reasons": reasons}


def check_all(schemes, profile, lang="en"):
    """Check every scheme in the list and return one result per scheme."""
    return [check_scheme(s, profile, lang) for s in schemes]


def missing_fields(scheme, profile):
    """Return the profile fields this scheme needs but the profile does not have.
    Possible names: "state", "education", "income", "course". Never guesses a value."""
    rules = scheme.get("eligibility", {}) or {}
    profile = profile or {}
    needed = []
    states = rules.get("states") or []
    # State is needed only when the scheme is not open to all of India
    if states and "All India" not in states and _clean(profile.get("state")) is None:
        needed.append("state")
    if (rules.get("education_levels") or []) and _clean(profile.get("education")) is None:
        needed.append("education")
    if rules.get("max_family_income") is not None and _income_value(profile.get("income")) is None:
        needed.append("income")
    keywords = [k for k in (rules.get("course_keywords") or []) if str(k).strip()]
    if keywords and _clean(profile.get("course")) is None:
        needed.append("course")
    return needed
