"""Simple keyword-based extraction of student details from Hindi/English text.

No external AI or NLP libraries are used. We only look for known keywords
and numbers. A field is filled ONLY when exactly one distinct value is found.
If nothing or two different values are found, the field stays None.
"""

import re
from typing import List, Optional


# ---- Education keywords (all lowercase) ----
EDUCATION_KEYWORDS = {
    "Class 10": ["class 10", "class x", "10th", "matric", "matriculation",
                 "दसवीं", "दसवी", "कक्षा 10", "कक्षा दस", "10वीं"],
    "Class 12": ["class 12", "class xii", "12th", "intermediate",
                 "बारहवीं", "बारहवी", "कक्षा 12", "कक्षा बारह", "12वीं", "12वी"],
    "Undergraduate": ["undergraduate", "b.tech", "btech", "b.e.", "bachelor",
                      "graduation", "graduate", "b.a.", "b.sc", "b.com", "bca", "bba",
                      "स्नातक", "बीटेक", "ग्रेजुएशन", "बी.टेक", "बीए", "बीएससी"],
    "Postgraduate": ["postgraduate", "post graduate", "post-graduate", "m.tech",
                     "mtech", "m.sc", "msc", "m.a.", "mba", "master",
                     "परास्नातक", "स्नातकोत्तर", "एमटेक", "एम.टेक", "एमएससी", "एमबीए"],
}

# If a postgraduate keyword is found, these Undergraduate keywords are ignored,
# because they are part of the postgraduate words (e.g. "postgraduate").
UNDERGRAD_DROP_WHEN_PG = ["graduate", "graduation", "स्नातक"]

# ---- State names: English name -> Hindi name (official list) ----
STATE_NAMES = {
    "Andhra Pradesh": "आंध्र प्रदेश",
    "Arunachal Pradesh": "अरुणाचल प्रदेश",
    "Assam": "असम",
    "Bihar": "बिहार",
    "Chhattisgarh": "छत्तीसगढ़",
    "Goa": "गोवा",
    "Gujarat": "गुजरात",
    "Haryana": "हरियाणा",
    "Himachal Pradesh": "हिमाचल प्रदेश",
    "Jharkhand": "झारखंड",
    "Karnataka": "कर्नाटक",
    "Kerala": "केरल",
    "Madhya Pradesh": "मध्य प्रदेश",
    "Maharashtra": "महाराष्ट्र",
    "Manipur": "मणिपुर",
    "Meghalaya": "मेघालय",
    "Mizoram": "मिज़ोरम",
    "Nagaland": "नागालैंड",
    "Odisha": "ओडिशा",
    "Punjab": "पंजाब",
    "Rajasthan": "राजस्थान",
    "Sikkim": "सिक्किम",
    "Tamil Nadu": "तमिलनाडु",
    "Telangana": "तेलंगाना",
    "Tripura": "त्रिपुरा",
    "Uttar Pradesh": "उत्तर प्रदेश",
    "Uttarakhand": "उत्तराखंड",
    "West Bengal": "पश्चिम बंगाल",
    # Union territories
    "Andaman and Nicobar Islands": "अंडमान और निकोबार द्वीप समूह",
    "Chandigarh": "चंडीगढ़",
    "Dadra and Nagar Haveli and Daman and Diu": "दादरा और नगर हवेली और दमन और दीव",
    "Delhi": "दिल्ली",
    "Jammu and Kashmir": "जम्मू और कश्मीर",
    "Ladakh": "लद्दाख",
    "Lakshadweep": "लक्षद्वीप",
    "Puducherry": "पुडुचेरी",
}

# ---- Income keywords and amount units ----
INCOME_KEYWORDS = ["income", "earn", "salary", "annual", "family income",
                   "आय", "कमाई", "वेतन", "सालाना", "आमदनी", "कमाते"]

# Number, optionally followed by a unit word (lakh, thousand, k, crore, Hindi words).
AMOUNT_RE = re.compile(
    r"(\d+(?:\.\d+)?)\s*(lakhs?|लाख|thousand|हज़ार|हजार|k(?![a-z])|crore|करोड़)?"
)


def _has_keyword(text: str, keywords: List[str]) -> bool:
    """Return True if any keyword is in the text.

    English keywords must not be part of a bigger word (so "earn" does not
    match "learn", and "class x" does not match "class xii").
    Hindi keywords are checked as plain substrings.
    """
    for kw in keywords:
        if kw.isascii():
            pattern = r"(?<![a-z0-9])" + re.escape(kw) + r"(?![a-z0-9])"
            if re.search(pattern, text):
                return True
        elif kw in text:
            return True
    return False


def _find_education(text: str) -> Optional[str]:
    """Return the one education level found, or None if zero or several."""
    has_pg = _has_keyword(text, EDUCATION_KEYWORDS["Postgraduate"])
    found = []
    for level, keywords in EDUCATION_KEYWORDS.items():
        if level == "Undergraduate" and has_pg:
            keywords = [k for k in keywords if k not in UNDERGRAD_DROP_WHEN_PG]
        if _has_keyword(text, keywords):
            found.append(level)
    if len(found) == 1:
        return found[0]
    return None


def _find_state(text: str) -> Optional[str]:
    """Return the one English state name found, or None if zero or several."""
    found = set()
    for english, hindi in STATE_NAMES.items():
        if _has_keyword(text, [english.lower()]) or hindi in text:
            found.add(english)
    if len(found) == 1:
        return found.pop()
    return None


def _unit_multiplier(unit: str) -> int:
    """Turn a unit word like 'lakh' or 'crore' into a multiplier."""
    if unit.startswith("lakh") or unit == "लाख":
        return 100000
    if unit.startswith("crore") or unit == "करोड़":
        return 10000000
    return 1000  # thousand, k, हज़ार, हजार


def _find_income(text: str) -> Optional[int]:
    """Return the one income amount (in rupees) found, or None."""
    # No income keyword anywhere -> we do not guess an income.
    if not _has_keyword(text, INCOME_KEYWORDS):
        return None

    values = set()
    for match in AMOUNT_RE.finditer(text):
        number = float(match.group(1))
        unit = match.group(2)

        if unit:
            value = number * _unit_multiplier(unit)
        else:
            # A bare number counts only if it is at least 1000.
            if number < 1000:
                continue
            value = number

        # An income keyword must be within 40 characters before or after.
        before = text[max(0, match.start() - 40):match.start()]
        after = text[match.end():match.end() + 40]
        if _has_keyword(before, INCOME_KEYWORDS) or _has_keyword(after, INCOME_KEYWORDS):
            values.add(int(round(value)))

    if len(values) == 1:
        return values.pop()
    return None


def extract_profile_from_text(text: str) -> dict:
    """Find state, education and income in a sentence. Missing or unclear -> None."""
    # Lowercase everything and remove commas inside numbers (2,50,000 -> 250000).
    cleaned = re.sub(r"(?<=\d),(?=\d)", "", (text or "").lower())
    if not cleaned.strip():
        return {"state": None, "education": None, "income": None}

    return {
        "state": _find_state(cleaned),
        "education": _find_education(cleaned),
        "income": _find_income(cleaned),
    }


def describe_found(result: dict) -> List[str]:
    """Return the names of the fields that were found (not None)."""
    return [field for field in ("state", "education", "income")
            if result.get(field) is not None]
